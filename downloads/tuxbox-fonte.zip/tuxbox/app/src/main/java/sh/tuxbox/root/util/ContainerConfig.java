// SPDX-License-Identifier: GPL-3.0-only
package sh.tuxbox.root.util;
import android.content.Context;
import android.content.SharedPreferences;
public final class ContainerConfig {
    public static final String[] PROFILES = {"unlimited", "eco", "balanced", "performance"};
    public static final String[] LABELS = {"Sem limite", "Econômico · 1 CPU / 1 GB", "Equilibrado · 2 CPUs / 2 GB", "Desempenho · 4 CPUs / 4 GB"};
    public String profile = "unlimited", sharedDirectory = "", ports = "";
    public boolean readOnly = true, disposable = false;
    public void validate() {
        boolean found = false; for (String p : PROFILES) found |= p.equals(profile);
        if (!found) throw new IllegalArgumentException("Perfil inválido");
        if (!sharedDirectory.isEmpty() && (!sharedDirectory.startsWith("/") || sharedDirectory.contains("\n") || sharedDirectory.contains("\r")))
            throw new IllegalArgumentException("Escolha um caminho absoluto para a pasta compartilhada.");
        if (!ports.isEmpty()) {
            if (!ports.matches("[0-9]{1,5}:[0-9]{1,5}")) throw new IllegalArgumentException("Portas: use início:fim, por exemplo 8080:8080.");
            String[] parts = ports.split(":"); int start = Integer.parseInt(parts[0]), end = Integer.parseInt(parts[1]);
            if (start < 1 || end > 65535 || start > end) throw new IllegalArgumentException("Portas devem estar entre 1 e 65535, em ordem crescente.");
        }
    }
    public static ContainerConfig load(Context context, String name) {
        SharedPreferences p = context.getSharedPreferences("container_" + ShellWords.name(name), Context.MODE_PRIVATE);
        ContainerConfig c = new ContainerConfig(); c.profile = p.getString("profile", "unlimited");
        c.sharedDirectory = p.getString("share", ""); c.ports = p.getString("ports", ""); c.readOnly = p.getBoolean("ro", true); c.disposable = p.getBoolean("disposable", false); return c;
    }
    public void save(Context context, String name) {
        validate(); context.getSharedPreferences("container_" + ShellWords.name(name), Context.MODE_PRIVATE).edit()
                .putString("profile", profile).putString("share", sharedDirectory).putString("ports", ports).putBoolean("ro", readOnly).putBoolean("disposable", disposable).apply();
    }
}
