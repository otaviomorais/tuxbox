// SPDX-License-Identifier: GPL-3.0-only
package sh.tuxbox.root.util;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream;
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream;
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Digest checks and tar-path validation before any root-side extraction. */
public final class ArchiveIntegrity {
    private ArchiveIntegrity() {}
    public static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[65536]; int n;
            while ((n = in.read(buffer)) != -1) digest.update(buffer, 0, n);
        }
        StringBuilder out = new StringBuilder(); for (byte b : digest.digest()) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 255)); return out.toString();
    }
    public static String manifestDigest(String manifest, String filename) throws IOException {
        for (String line : manifest.split("\\r?\\n")) {
            String[] pair = line.trim().split("\\s+", 2);
            if (pair.length == 2 && pair[0].matches("[A-Fa-f0-9]{64}") && pair[1].replaceFirst("^\\*", "").equals(filename)) return pair[0].toLowerCase(java.util.Locale.ROOT);
        }
        throw new IOException("SHA256SUMS não contém " + filename);
    }
    public static void verify(File file, String expected) throws Exception {
        if (expected == null || !expected.matches("[A-Fa-f0-9]{64}") || !sha256(file).equalsIgnoreCase(expected)) throw new IOException("SHA-256 divergente; arquivo não será instalado.");
    }
    static String normalize(String base, String path) throws IOException {
        if (path.startsWith("/") || path.indexOf('\0') >= 0 || path.length() > 4096) throw new IOException("Caminho inválido no tar: " + path);
        ArrayDeque<String> parts = new ArrayDeque<>();
        for (String part : (base + "/" + path).split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) { if (parts.isEmpty()) throw new IOException("Caminho escapa do rootfs: " + path); parts.removeLast(); }
            else parts.addLast(part);
        }
        return String.join("/", parts);
    }
    static String resolveParents(String name, Map<String, String> links) throws IOException {
        String current = name;
        for (int hop = 0; hop < 64; hop++) {
            boolean changed = false; int slash = current.indexOf('/');
            while (slash >= 0) {
                String prefix = current.substring(0, slash), target = links.get(prefix);
                if (target != null) {
                    int parent = prefix.lastIndexOf('/');
                    current = normalize(parent < 0 ? "" : prefix.substring(0, parent), target + current.substring(slash));
                    changed = true; break;
                }
                slash = current.indexOf('/', slash + 1);
            }
            if (!changed) return current;
        }
        throw new IOException("Ciclo de symlinks no tar");
    }
    public static void validateTar(File file) throws IOException {
        Map<String, String> links = new HashMap<>(); List<String> paths = new ArrayList<>(); List<String> hardlinks = new ArrayList<>();
        java.util.Set<String> directories = new java.util.HashSet<>(), members = new java.util.HashSet<>(), regular = new java.util.HashSet<>();
        long pathBudget = 0;
        try (BufferedInputStream raw = new BufferedInputStream(new FileInputStream(file))) {
            raw.mark(8); int first = raw.read(), second = raw.read(); raw.reset();
            InputStream content = first == 0xfd && second == 0x37 ? new XZCompressorInputStream(raw)
                    : first == 0x1f && second == 0x8b ? new GzipCompressorInputStream(raw) : raw;
            try (TarArchiveInputStream tar = new TarArchiveInputStream(content)) {
                TarArchiveEntry entry;
                while ((entry = tar.getNextTarEntry()) != null) {
                    if (paths.size() >= 1000000) throw new IOException("Tar contém entradas demais");
                    pathBudget += entry.getName().length() + entry.getLinkName().length();
                    if (pathBudget > 64L * 1024 * 1024) throw new IOException("Metadados do tar excedem o orçamento de memória");
                    String name = normalize("", entry.getName());
                    if (name.isEmpty() && !entry.isDirectory()) throw new IOException("Entrada substitui a raiz do tar");
                    if (!members.add(name) && !(entry.isDirectory() && directories.contains(name))) throw new IOException("Entrada duplicada no tar: " + name);
                    if (entry.isDirectory()) directories.add(name);
                    if (entry.isFile()) regular.add(name);
                    paths.add(name);
                    if (entry.isSymbolicLink()) {
                        String target = entry.getLinkName();
                        if (!target.startsWith("/")) {
                            int slash = name.lastIndexOf('/'); normalize(slash < 0 ? "" : name.substring(0, slash), target);
                        }
                        if (links.put(name, target) != null) throw new IOException("Symlink duplicado no tar: " + name);
                    }
                    if (entry.isLink()) hardlinks.add(normalize("", entry.getLinkName()));
                    if (!tar.canReadEntryData(entry)) throw new IOException("Entrada tar não suportada: " + name);
                }
            }
        }
        if (paths.isEmpty()) throw new IOException("Arquivo tar vazio ou inválido");
        for (String name : paths) resolveParents(name, links);
        java.util.Set<String> resolvedRegular = new java.util.HashSet<>();
        for (String name : regular) resolvedRegular.add(resolveParents(name, links));
        for (String name : hardlinks) {
            String resolved = resolveParents(name, links);
            if (links.containsKey(resolved) || !resolvedRegular.contains(resolved)) throw new IOException("Hardlink não aponta para arquivo regular: " + name);
        }
    }
}
