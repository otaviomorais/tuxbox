// SPDX-License-Identifier: GPL-3.0-only
package sh.tuxbox.root.ui;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import sh.tuxbox.root.MainActivity;
import sh.tuxbox.root.R;
import sh.tuxbox.root.RootShell;
import sh.tuxbox.root.SessionManager;
import sh.tuxbox.root.util.AssetInstaller;
import sh.tuxbox.root.util.ContainerConfig;
import sh.tuxbox.root.util.ShellWords;
import sh.tuxbox.root.util.TuxPaths;

/** Container dashboard: lifecycle, configuration and rootfs operations. */
public class RootfsFragment extends Fragment {
    private LinearLayout listRootfs;
    private TextView tvFree, tvSummary;
    private View cardNone, progress;
    private MaterialButton btnRefresh;
    private int generation;
    private final List<String> names = new ArrayList<>();
    private final Runnable sessionsChanged = this::render;
    private SessionManager manager;

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup parent, @Nullable Bundle state) {
        return i.inflate(R.layout.fragment_rootfs, parent, false);
    }
    @Override public void onViewCreated(@NonNull View view, @Nullable Bundle state) {
        manager = SessionManager.get(requireContext());
        listRootfs = view.findViewById(R.id.listRootfs); tvFree = view.findViewById(R.id.tvFree);
        tvSummary = view.findViewById(R.id.tvContainerSummary); progress = view.findViewById(R.id.rootfsProgress);
        cardNone = view.findViewById(R.id.cardNone); btnRefresh = view.findViewById(R.id.btnRefresh);
        btnRefresh.setOnClickListener(v -> refresh());
        view.findViewById(R.id.btnCapabilities).setOnClickListener(v -> capabilities());
        manager.observe(sessionsChanged);
    }
    @Override public void onResume() { super.onResume(); refresh(); }
    @Override public void onDestroyView() { generation++; manager.unobserve(sessionsChanged); super.onDestroyView(); }
    private void refresh() {
        int request = ++generation;
        progress.setVisibility(View.VISIBLE); btnRefresh.setEnabled(false);
        final Context context = requireContext().getApplicationContext();
        RootShell.EXEC.execute(() -> {
            String output; int code;
            try {
                AssetInstaller.install(context);
                RootShell.CommandResult shell = RootShell.execute("( [ \"$(id -u)\" -eq 0 ] || exit 1; sh " + ShellWords.quote(new File(AssetInstaller.binDir(context), "tuxbox-control").getAbsolutePath())
                        + " status || exit 1; echo TUXBOX_NAMES; " + TuxPaths.LIST_ROOTFS_CMD
                        + "; echo TUXBOX_STORAGE; df -h /data/local 2>/dev/null | tail -n1 | awk '{print $4\" livre de \"$2}'; )");
                output = shell.output; code = shell.code;
            } catch (Exception e) { output = "ERR: " + e; code = -1; }
            final String result = output; final int exitCode = code;
            Activity activity = getActivity(); if (activity == null) return;
            activity.runOnUiThread(() -> {
                if (request != generation || getView() == null) return;
                manager.reconcileRootState(result);
                names.clear(); boolean storage = false, listing = false;
                for (String raw : result.split("\\r?\\n")) {
                    String line = raw.trim();
                    if (line.equals("TUXBOX_NAMES")) { listing = true; continue; }
                    if (!listing) continue;
                    if (line.equals("TUXBOX_STORAGE")) { storage = true; continue; }
                    if (line.isEmpty() || line.startsWith("$") || line.startsWith("ERR:") || line.startsWith("[")) continue;
                    if (storage) { tvFree.setText(line); continue; }
                    try { names.add(ShellWords.name(line)); } catch (IllegalArgumentException ignored) { }
                }
                Collections.sort(names); progress.setVisibility(View.GONE); btnRefresh.setEnabled(true); render();
                if (exitCode != 0) Toast.makeText(activity, "Não foi possível atualizar: verifique o acesso root.", Toast.LENGTH_LONG).show();
            });
        });
    }
    private void render() {
        if (getView() == null) return;
        listRootfs.removeAllViews(); cardNone.setVisibility(names.isEmpty() ? View.VISIBLE : View.GONE);
        tvSummary.setText(names.size() + " ambiente(s) · " + manager.runningCount() + " sessão(ões) ativa(s) · " + manager.operationCount() + " operação(ões)");
        for (String name : names) listRootfs.addView(card(name));
    }
    private View card(String name) {
        boolean running = manager.isRunning(name);
        String operation = manager.operationLabel(name);
        ContainerConfig config = ContainerConfig.load(requireContext(), name);
        MaterialCardView card = new MaterialCardView(requireContext()); card.setRadius(dp(18));
        card.setCardElevation(0); card.setStrokeWidth(dp(1)); card.setStrokeColor(color(running ? R.color.tux_green : R.color.tux_stroke));
        card.setCardBackgroundColor(color(R.color.tux_surface));
        LinearLayout.LayoutParams bounds = new LinearLayout.LayoutParams(-1, -2); bounds.bottomMargin = dp(10); card.setLayoutParams(bounds);
        LinearLayout content = column(); content.setPadding(dp(16), dp(14), dp(16), dp(14)); card.addView(content);
        TextView title = text(name, 18, R.color.tux_text); title.setTypeface(null, android.graphics.Typeface.BOLD); content.addView(title);
        int sessions = 0; for (SessionManager.Session session : manager.sessions()) if (session.label.equals(name) && session.running()) sessions++;
        sessions += manager.recoveredCount(name);
        String detail = (running ? "Em execução · " + sessions + " sessão(ões)" : "Parado") + "  ·  " + profileLabel(config.profile);
        if (operation != null) detail = operation;
        TextView status = text(detail, 12, running ? R.color.tux_green : R.color.tux_text_secondary); status.setPadding(0, dp(6), 0, dp(10)); content.addView(status);
        if (!config.sharedDirectory.isEmpty()) content.addView(text("/mnt/shared · " + (config.readOnly ? "somente leitura" : "leitura e escrita"), 12, R.color.tux_text_secondary));
        LinearLayout actions = new LinearLayout(requireContext()); actions.setGravity(android.view.Gravity.CENTER_VERTICAL);
        MaterialButton terminal = button(running ? "Terminal" : "Iniciar", R.color.tux_cyan, v -> openTerminal(name));
        terminal.setEnabled(operation == null);
        actions.addView(terminal, new LinearLayout.LayoutParams(0, dp(48), 1));
        if (running) actions.addView(button("Parar", R.color.tux_red, v -> stop(name)), new LinearLayout.LayoutParams(0, dp(48), 1));
        MaterialButton more = button("Mais", R.color.tux_violet_light, v -> menu(name, v)); more.setContentDescription("Mais ações para " + name); more.setEnabled(operation == null);
        actions.addView(more, new LinearLayout.LayoutParams(0, dp(48), 1)); content.addView(actions);
        return card;
    }
    private String profileLabel(String profile) {
        for (int i = 0; i < ContainerConfig.PROFILES.length; i++) if (ContainerConfig.PROFILES[i].equals(profile)) return ContainerConfig.LABELS[i];
        return "Sem limite";
    }
    private void menu(String name, View anchor) {
        PopupMenu popup = new PopupMenu(requireContext(), anchor);
        String[] actions = {"Configurar", "Fazer backup", "Clonar", "Instalar template", "Diagnóstico da sessão", "Reparar execução", "Excluir"};
        for (int i = 0; i < actions.length; i++) popup.getMenu().add(0, i, i, actions[i]);
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 0: configure(name); break;
                case 1: if (stopped(name)) operation("backup", name, null); break;
                case 2: if (stopped(name)) cloneDialog(name); break;
                case 3: templates(name); break;
                case 4: diagnostics(name); break;
                case 5: if (stopped(name)) new MaterialAlertDialogBuilder(requireContext()).setTitle("Reparar execução?")
                        .setMessage("Restaura execução dos programas em bin/sbin e rótulos SELinux. Não altera permissões dos dados privados.")
                        .setNegativeButton("Cancelar", null).setPositiveButton("Reparar", (d, w) -> operation("repair", name, null)).show(); break;
                case 6: if (stopped(name)) new MaterialAlertDialogBuilder(requireContext()).setTitle("Excluir " + name + "?")
                        .setMessage("O rootfs será removido. Backups existentes serão preservados.")
                        .setNegativeButton("Cancelar", null).setPositiveButton("Excluir", (d, w) -> operation("delete", name, null)).show(); break;
            }
            return true;
        }); popup.show();
    }
    private boolean stopped(String name) {
        if (!manager.isRunning(name)) return true;
        Toast.makeText(requireContext(), "Pare todas as sessões deste container primeiro.", Toast.LENGTH_LONG).show(); return false;
    }
    private void stop(String name) {
        new MaterialAlertDialogBuilder(requireContext()).setTitle("Parar " + name + "?").setMessage("Os processos das sessões deste container serão encerrados.")
                .setNegativeButton("Cancelar", null).setPositiveButton("Parar", (d, w) -> manager.stop(name)).show();
    }
    private void openTerminal(String name) {
        // Reuse the existing PTY instead of booting another namespace unnecessarily.
        for (int i = 0; i < manager.sessions().size(); i++) if (manager.sessions().get(i).label.equals(name) && manager.sessions().get(i).running()) { manager.activate(i); break; }
        if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).openTerminalTab(name);
        boolean attached = false;
        for (SessionManager.Session s : manager.sessions()) if (s.label.equals(name) && s.running()) attached = true;
        if (!attached) manager.launch(name, false, false, error -> showLaunchError(error));
    }
    private void showLaunchError(String error) {
        if (error != null && isAdded()) Toast.makeText(requireContext(), error, Toast.LENGTH_LONG).show();
    }
    private void configure(String name) {
        ContainerConfig c = ContainerConfig.load(requireContext(), name);
        LinearLayout form = column(); form.setPadding(dp(20), dp(10), dp(20), dp(10));
        form.addView(text("Recursos", 14, R.color.tux_text));
        Spinner profile = new Spinner(requireContext()); profile.setAdapter(new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, ContainerConfig.LABELS));
        profile.setSelection(Math.max(0, java.util.Arrays.asList(ContainerConfig.PROFILES).indexOf(c.profile))); form.addView(profile);
        form.addView(text("Limites exigem cgroups disponíveis. Aplicados na próxima sessão.", 12, R.color.tux_text_secondary));
        CheckBox disposable = new CheckBox(requireContext()); disposable.setText("Sessão descartável (OverlayFS)"); disposable.setChecked(c.disposable); form.addView(disposable);
        form.addView(text("Alterações no rootfs serão descartadas ao fechar. Pastas compartilhadas com escrita continuam persistentes.", 12, R.color.tux_text_secondary));
        EditText share = input("Pasta do Android (opcional)", c.sharedDirectory); form.addView(share);
        CheckBox ro = new CheckBox(requireContext()); ro.setText("Compartilhar somente para leitura"); ro.setChecked(c.readOnly); form.addView(ro);
        form.addView(text("A pasta aparecerá em /mnt/shared.", 12, R.color.tux_text_secondary));
        EditText ports = input("Portas: início:fim (opcional)", c.ports); form.addView(ports);
        form.addView(text("Encaminhamento só na sessão com Rede isolada. As portas podem ficar acessíveis na rede do aparelho.", 12, R.color.tux_text_secondary));
        ScrollView scroll = new ScrollView(requireContext()); scroll.addView(form);
        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext()).setTitle("Configurar " + name).setView(scroll)
                .setNegativeButton("Cancelar", null).setPositiveButton("Salvar", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try { c.profile = ContainerConfig.PROFILES[profile.getSelectedItemPosition()]; c.sharedDirectory = share.getText().toString().trim();
                c.ports = ports.getText().toString().trim(); c.readOnly = ro.isChecked(); c.disposable = disposable.isChecked(); c.save(requireContext(), name); dialog.dismiss(); render(); }
            catch (Exception e) { Toast.makeText(requireContext(), e.getMessage(), Toast.LENGTH_LONG).show(); }
        })); dialog.show();
    }
    private void cloneDialog(String name) {
        EditText input = input("Nome do novo container", name + "-copia");
        AlertDialog dialog = new MaterialAlertDialogBuilder(requireContext()).setTitle("Clonar " + name).setView(input).setNegativeButton("Cancelar", null).setPositiveButton("Clonar", null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            try { String target = ShellWords.name(input.getText().toString().trim()); dialog.dismiss(); operation("clone", name, target); }
            catch (Exception e) { input.setError(e.getMessage()); }
        })); dialog.show();
    }
    private void templates(String name) {
        if (ContainerConfig.load(requireContext(), name).disposable) {
            Toast.makeText(requireContext(), "Desative Sessão descartável antes de instalar um template permanente.", Toast.LENGTH_LONG).show(); return;
        }
        String[] labels = {"Desenvolvimento · Git, C/C++, Python", "Desktop · XFCE", "Serviços · SSH, Nginx"};
        String[] ids = {"development", "desktop", "services"};
        new MaterialAlertDialogBuilder(requireContext()).setTitle("Instalar no " + name).setItems(labels, (d, which) -> {
            new MaterialAlertDialogBuilder(requireContext()).setTitle(labels[which]).setMessage("Baixa e instala pacotes pela distro. A saída aparece no terminal; serviços não são iniciados automaticamente.")
                    .setNegativeButton("Cancelar", null).setPositiveButton("Instalar", (a, b) -> {
                        if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).openTerminalTab(name);
                        manager.launchTemplate(name, ids[which], this::showLaunchError);
                    }).show();
        }).show();
    }
    private void operation(String action, String name, String extra) {
        try { manager.beginOperation(name, (action.equals("backup") ? "Criando backup" : action.equals("clone") ? "Clonando" : action.equals("repair") ? "Reparando" : "Excluindo") + " " + name); }
        catch (Exception e) { Toast.makeText(requireContext(), e.getMessage(), Toast.LENGTH_LONG).show(); return; }
        final Context context = requireContext().getApplicationContext();
        progress.setVisibility(View.VISIBLE);
        tvSummary.setText((action.equals("backup") ? "Criando backup" : action.equals("clone") ? "Clonando" : action.equals("repair") ? "Reparando" : "Excluindo") + " " + name + "…");
        // Long file operations are not falsely timed out after the diagnostic shell's 12 seconds.
        RootShell.FILE_OPERATIONS.execute(() -> {
            String output; int code;
            try { AssetInstaller.install(context); String command = "sh " + ShellWords.quote(new File(AssetInstaller.binDir(context), "tuxbox-control").getAbsolutePath())
                    + " " + action + " " + ShellWords.quote(name) + (extra == null ? "" : " " + ShellWords.quote(extra));
                RootShell.CommandResult shell = RootShell.executeIsolated(command); output = shell.output; code = shell.code;
            } catch (Exception e) { output = e.toString(); code = -1; }
            final String result = output; final int exitCode = code;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(() -> {
                manager.finishOperation(name);
                if (getView() == null) return;
                if (extra != null && exitCode == 0) ContainerConfig.load(context, name).save(context, extra);
                String brief = result.length() > 1800 ? result.substring(result.length() - 1800) : result;
                if (exitCode == 0) {
                    if (action.equals("clone")) brief = "Novo ambiente criado: " + extra;
                    else if (action.equals("delete")) brief = "Ambiente excluído: " + name;
                    else if (action.equals("repair")) brief = "Execução de /bin/sh verificada.";
                    else {
                        String path = "";
                        for (String line : result.split("\\r?\\n")) {
                            if (line.startsWith("BACKUP=")) path = line.substring(7);
                            if (line.startsWith("DOWNLOADS=")) { path = line.substring(10); break; }
                        }
                        brief = "Backup salvo em:\n" + path + "\n\nSHA-256: " + path + ".sha256";
                    }
                }
                new MaterialAlertDialogBuilder(requireContext()).setTitle(exitCode == 0 ? "Operação concluída" : "Operação falhou")
                        .setMessage(brief + (action.equals("backup") ? "\n\nPara restaurar, importe o .tar em Baixar / Importar com um novo nome." : ""))
                        .setPositiveButton("OK", null).show(); refresh();
            });
        });
    }
    private void capabilities() {
        final Context context = requireContext().getApplicationContext();
        RootShell.EXEC.execute(() -> {
            String output;
            try { AssetInstaller.install(context); output = RootShell.execute("sh " + ShellWords.quote(new File(AssetInstaller.binDir(context), "tuxbox-capabilities").getAbsolutePath())).output; }
            catch (Exception e) { output = e.toString(); }
            final String result = output;
            Activity activity = getActivity(); if (activity == null) return;
            activity.runOnUiThread(() -> { if (getView() != null) new MaterialAlertDialogBuilder(requireContext()).setTitle("Capacidades do aparelho")
                    .setMessage(result).setPositiveButton("OK", null).show(); });
        });
    }
    private void diagnostics(String name) {
        StringBuilder result = new StringBuilder();
        for (SessionManager.Session s : manager.sessions()) if (s.label.equals(name)) result.append(s.id).append(" · ")
                .append(s.running() ? "Em execução" : "exit=" + s.exitCode).append("\n").append(s.diagnostics()).append("\n");
        new MaterialAlertDialogBuilder(requireContext()).setTitle("Sessões de " + name).setMessage(result.length() == 0 ? "Sem sessões nesta execução do app." : result.toString()).setPositiveButton("OK", null).show();
    }
    private LinearLayout column() { LinearLayout v = new LinearLayout(requireContext()); v.setOrientation(LinearLayout.VERTICAL); return v; }
    private TextView text(String value, int size, int color) { TextView v = new TextView(requireContext()); v.setText(value); v.setTextSize(size); v.setTextColor(color(color)); return v; }
    private EditText input(String hint, String value) { EditText v = new EditText(requireContext()); v.setSingleLine(true); v.setTextSize(14); v.setTextColor(color(R.color.tux_text)); v.setHintTextColor(color(R.color.tux_text_secondary)); v.setHint(hint); v.setText(value); return v; }
    private MaterialButton button(String title, int color, View.OnClickListener action) {
        MaterialButton b = new MaterialButton(requireContext()); b.setText(title); b.setAllCaps(false); b.setMinWidth(0); b.setMinimumWidth(0);
        b.setTextColor(color(color)); b.setBackgroundTintList(ColorStateList.valueOf(0x00000000)); b.setOnClickListener(action); return b;
    }
    private int color(int resource) { return requireContext().getColor(resource); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
