// SPDX-License-Identifier: GPL-3.0-only
// Copyright (C) 2026 LongQT-sea
package sh.tuxbox.root;

import com.topjohnwu.superuser.Shell;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public final class RootShell {
    private RootShell() {}

    /** Single shared executor for root commands so we never block the UI thread. */
    public static final ExecutorService EXEC = Executors.newFixedThreadPool(2);
    public static final ExecutorService FILE_OPERATIONS = Executors.newSingleThreadExecutor();

    /**
     * v3.10 — pool elástico para os jobs de root: um job pendurado (su/libsu
     * travado, como o daemon do KernelSU em crash) fica preso na SUA thread e
     * não ocupa as duas do pool, evitando travar toda a UI.
     */
    private static final ExecutorService JOBS = Executors.newCachedThreadPool();

    /** Segundos que esperamos por um comando de root antes de desistir dele. */
    private static final long TIMEOUT_S = 12;

    public interface Callback {
        void done(String output);
    }

    /**
     * v3.10 — o callback SEMPRE dispara: mesmo que o `su` fique pendurado
     * indefinidamente, a UI recebe resposta em ~TIMEOUT_S s em vez de ficar
     * girando (o libsu 5.2.2 não tem timeout nativo).
     */
    public static void runAsync(String cmd, Callback cb) {
        EXEC.execute(() -> {
            String out;
            Future<String> job = JOBS.submit(() -> run(cmd));
            try {
                out = job.get(TIMEOUT_S, TimeUnit.SECONDS);
            } catch (TimeoutException t) {
                job.cancel(true);
                out = "[timeout " + TIMEOUT_S + "s ao esperar root] " + cmd;
            } catch (Exception t) {
                out = "[erro ao rodar root: " + t + "]";
            }
            cb.done(out);
        });
    }

    public static final class CommandResult {
        public final int code;
        public final String output;
        CommandResult(int code, String output) { this.code = code; this.output = output; }
    }
    /** Structured result for product flows; stdout cannot spoof a successful exit code. */
    public static CommandResult execute(String cmd) {
        Shell.Result result = Shell.cmd(cmd).exec();
        StringBuilder out = new StringBuilder();
        for (String line : result.getOut()) out.append(line).append("\n");
        for (String line : result.getErr()) out.append(line).append("\n");
        return new CommandResult(result.getCode(), out.toString());
    }
    public interface ResultCallback { void done(CommandResult result); }
    public static void executeAsync(String cmd, ResultCallback callback) {
        EXEC.execute(() -> {
            Future<CommandResult> job = JOBS.submit(() -> execute(cmd));
            CommandResult result;
            try { result = job.get(TIMEOUT_S, TimeUnit.SECONDS); }
            catch (Exception e) { job.cancel(true); result = new CommandResult(-1, "Não foi possível obter resposta do root: " + e.getClass().getSimpleName()); }
            callback.done(result);
        });
    }
    /** File operations get their own su process so a large tar cannot block diagnostic jobs. */
    public static CommandResult executeIsolated(String cmd) throws Exception {
        Process process = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
        StringBuilder output = new StringBuilder();
        try {
            process.getOutputStream().close();
            try (java.io.BufferedReader in = new java.io.BufferedReader(new java.io.InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = in.readLine()) != null) {
                    output.append(line).append("\n");
                    if (output.length() > 131072) output.delete(0, output.length() - 131072);
                }
            }
            return new CommandResult(process.waitFor(), output.toString());
        } finally { process.destroy(); }
    }
    /** Backward-compatible diagnostic formatting. */
    public static String run(String cmd) {
        CommandResult result = execute(cmd);
        return "$ " + cmd + "\n" + result.output + "[exit=" + result.code + "]\n";
    }

    /** Return true if the su shell actually has uid 0. */
    public static boolean isRoot() {
        try {
            Shell shell = Shell.getShell();
            return shell != null && shell.isRoot();
        } catch (Throwable t) {
            return false;
        }
    }
}