package sh.tuxbox.root.util;
import org.junit.Test;
import java.util.Arrays;
import static org.junit.Assert.*;
public class ConfigurationTest {
    @Test public void validatesLimitsAndRejectsBadRanges() {
        ContainerConfig config = new ContainerConfig(); config.ports = "8080:8080"; config.validate();
        for (String invalid : Arrays.asList("0:80", "80:70000", "9000:8000", "80;id", "1:2:3")) {
            config.ports = invalid; assertThrows(IllegalArgumentException.class, config::validate);
        }
        config.ports = ""; config.profile = "unexpected"; assertThrows(IllegalArgumentException.class, config::validate);
    }
    @Test public void quotesShellMetacharactersAsOneWord() {
        assertEquals("'a'\"'\"'b'", ShellWords.quote("a'b"));
        assertEquals("'a b' '$(id)'", ShellWords.join(Arrays.asList("a b", "$(id)")));
        assertThrows(IllegalArgumentException.class, () -> ShellWords.name("../other"));
        assertThrows(IllegalArgumentException.class, () -> ShellWords.name("x;id"));
    }
}
