# Gestão de containers e validação

O painel mostra ambientes instalados, sessões locais e execuções encontradas no
registro do supervisor. **Iniciar** abre uma sessão; **Terminal** reaproveita uma
PTY ativa. O menu **Mais** oferece configuração, backup, clonagem, templates,
diagnóstico, reparo de execução e exclusão. Arquivos privados mantêm seus modos:
o instalador não aplica mais chmod/chown recursivo ao rootfs.

## Sessões

`SessionManager`, pertencente à Application, controla processos, buffers,
cancelamento de inicializações, saída e observadores da interface. Os clients de
terminal são desacoplados ao destruir a view. `TerminalService` fornece notificação
com retorno ao app e parada das sessões. Operações longas também mantêm o serviço
ativo e usam um processo `su` separado para não bloquear diagnósticos.

Fechar uma aba solicita encerramento ao supervisor; a ponte PTY oferece um prazo
para limpeza antes de forçar a parada. PID e instante de criação em `/proc` evitam
que um arquivo antigo encerre um processo que reutilizou o PID.

A memória da PTY não sobrevive à morte do processo Android. A notificação deixou
de prometer essa recuperação com START_STICKY. Execuções ainda vivas encontradas
no registro podem ser paradas ou ganhar uma nova sessão, sem fingir reconexão ao
terminal perdido. Isso também não implementa um daemon independente persistente.

## Configuração por ambiente

- **Sem limite** é o padrão. Eco, equilibrado e desempenho limitam cada sessão a
  1/2/4 CPUs equivalentes e 1/2/4 GiB de RAM. Precisam de CPU e memória disponíveis
  em cgroup v1, ou delegadas em v2. Não habilitam controladores globalmente; falham
  explicitamente se o kernel/contexto não permitir os limites pedidos.
- **Sessão descartável** cria uma camada OverlayFS num mount namespace privado.
  Alterações na camada são descartadas ao encerrar. Não muda pastas externas
  compartilhadas com escrita. Falha explicitamente quando OverlayFS não funciona.
- **Pasta compartilhada** aparece em `/mnt/shared`, somente leitura por padrão.
  Os lançamentos pelo app deixam de expor automaticamente todo o armazenamento
  Android. O launcher standalone conserva o comportamento anterior.
- **Portas início:fim** configura o encaminhamento existente de TCP/UDP, somente
  ao abrir uma sessão com rede isolada. As portas podem ficar acessíveis pela
  interface de rede do aparelho; não há conversão de uma porta para outra.

No modo gerenciado, cada sessão de rede recebe seu namespace/veth; a alocação
consulta os IPs ocupados e é serializada para evitar colisões. A limpeza remove
namespace, veth e encaminhamentos pertencentes à sessão. A bridge compartilhada e
as regras gerais de roteamento permanecem disponíveis para outras sessões.

**Capacidades do aparelho** exercita namespaces e distingue ferramentas instaladas
de suporte confirmado. A presença de `docker`/`lxc-start` não prova saúde de daemon
ou suporte do kernel. Docker e LXC não são backends de execução novos nesta versão;
o backend nativo do TuxBox permanece em uso.

## Backup, clone, restauração e instalação

Backup e clone exigem rootfs parado e sem mounts ativos. Locks com identidade de
processo coordenam manutenção e inicialização, recuperando locks de processos
mortos. Um clone ou instalação não sobrescreve um destino já existente.

Backups são `.tar` com SHA-256 em `/data/local/tuxbox-archives`, e recebem cópia em
`Download/TuxBox` quando o armazenamento permite. Excluem arquivos temporários e
pseudo-filesystems. Preservam arquivos, symlinks, modos e ownership; não prometem
capturar todos os xattrs/ACLs de um snapshot de filesystem.

Para restaurar, importe o `.tar` em **Baixar / Importar** com um novo nome. A
extração usa staging e renomeação no mesmo filesystem. Falhas deixam o ambiente
existente intacto. **Reparar execução** ajusta execução em bin/sbin e restorecon;
não deixa arquivos privados legíveis para todos.

Novos downloads do linuxcontainers.org são conferidos contra `SHA256SUMS` via
HTTPS. Mesa exige o digest SHA-256 informado pelo asset da API GitHub. Cache e
importações locais têm sua identidade registrada/verificada quando há sidecar;
antes de extrair, o app rejeita traversal, duplicações perigosas e escrita através
de symlinks que escapem do staging. Um digest obtido do mesmo publicador verifica
integridade/origem HTTPS, não uma assinatura independente. Imagens locais e caches
legados sem manifesto continuam dependendo da confiança do usuário na imagem.

Os helpers Arch mantêm assinaturas obrigatórias e TrustedOnly. DisableSandbox
continua atendendo kernels sem Landlock. A keyring oficial é inicializada; erro de
assinatura não é contornado com TrustAll. O instalador de Mesa usa uma configuração
temporária para pacotes locais previamente verificados por digest. O downloader
legado deixou de desativar TLS e de definir uma senha universal de root.

## Templates

Desenvolvimento, XFCE e serviços SSH/Nginx instalam pacotes com apt/apk/pacman. A
saída aparece numa sessão real; falhas aparecem no código de saída do template.
Serviços não são iniciados nem publicados automaticamente. Templates permanentes
exigem desativar o modo descartável.

## Build e testes

A APK debug é **TuxBox Dev** (`sh.tuxbox.root.dev`) e pode ser instalada ao lado da
release. Ambas usam os rootfs em `/data/local/tuxbox`: use um clone para experimentar.
A APK tem assinatura de desenvolvimento, não a chave da release do proprietário.

```sh
./gradlew :app:testDebugUnitTest :app:assembleDebug :app:lintDebug
sh tool/test/container-control.test.sh
sh tool/test/network-allocation.test.sh
sh tool/test/ensure-x11-clients.test.sh
sh tool/test/tuxbox-kernel-check.test.sh
mkdir -p work
cc -O2 -Wall -Wextra -Werror tool/ptyd.c -lutil -o work/ptyd-test
python3 tool/test/ptyd_test.py work/ptyd-test
```

Os testes de chroot, namespaces e OverlayFS precisam de root/capabilities no Linux.
O teste OverlayFS só roda quando o ambiente oferece mount namespace; o filesystem
da camada superior também deve suportar OverlayFS (tmpfs serve para esse teste).
Os testes de UI usam um card de fixture, identificado como `debian-teste`, sem
instalar uma distro; verificam renderização, configuração e recriação de Activity.

Para compilar sem JitPack, obtenha a fonte original do libsu 5.2.2, commit
`30da9269455ffd6801b237d19cbfd43b7171f6f4`, e passe:

```sh
./gradlew -PtuxboxLibsuSource=/caminho/para/libsu :app:assembleDebug
```

`tool/libsu-local` compila a fonte original, sem trocar a API do libsu. O build
normal conserva a dependência publicada. Para reconstruir os helpers Android:

```sh
NDKBIN=/caminho/android-ndk-r26d/toolchains/llvm/prebuilt/linux-x86_64/bin python3 tool/build-ptyd.py
```

O script executa o NDK diretamente em x86_64 e conserva o caminho QEMU para hosts
ARM64. Os três binários (arm64-v8a, armeabi-v7a, x86_64) precisam acompanhar o source.
Android real ainda é necessário para validar Magisk/KernelSU, política SELinux,
GPU/X11, cgroups e peculiaridades de networking do aparelho. Nenhum ganho numérico
de desempenho no celular é declarado pelos testes em Linux ou emulador.

## Registro desta entrega — 2026-10-14

- APK `sh.tuxbox.root.dev`, versão 1.1.0-dev / código 28, gerada e assinatura
  verificada com apksigner.
- Gradle: assembleDebug, testDebugUnitTest e lintDebug concluídos com sucesso.
- 7 testes Java de integridade de arquivo e configuração: 0 falhas/erros.
- 6 testes do binário PTY real em Linux: fragmentação, resize, backpressure,
  código de saída, desconexão, pacote inválido e encerramento de descendentes.
- Backup/restauração/clonagem, modos privados, rootfs ativo, PID reutilizado,
  locks interrompidos e OverlayFS: verificações de integração concluídas.
- Alocação de IP após liberação de endereço: regressão corrigida e verificada.
- Scripts X11: 46 verificações passaram; diagnóstico de kernel: 31 passaram.
- Teste instrumentado em Android 11/API 30, emulador x86_64: 1 teste passou,
  cobrindo card real, diálogo, persistência da configuração e recriação da Activity.
- Helpers reconstruídos com NDK r26d para as três ABIs; TLS ARM64 mantém alinhamento 64.

As capturas usam o card de demonstração `debian-teste`. Não representam execução
real de uma distro no emulador. Magisk/KernelSU, GPU/X11, perfis cgroups, rede Android
real e dispositivos com páginas de 16 KiB continuam exigindo validação no aparelho.
