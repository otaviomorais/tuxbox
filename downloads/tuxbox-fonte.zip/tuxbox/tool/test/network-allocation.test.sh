#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
# Isolate the actual allocator function, without running host boot/mount setup.
awk '/^get_next_ip\(\)/ {p=1} /^find_free_subnet\(\)/ {p=0} p' "$HERE/../../app/src/main/assets/bin/tuxbox" > "$TMP/allocator.sh"
. "$TMP/allocator.sh"
NET_PREFIX=10.11.0; BRIDGE=tuxbox_br1; NETNS_DIR="$TMP/netns"
mkdir "$NETNS_DIR"; touch "$NETNS_DIR/tuxbox_br1-a" "$NETNS_DIR/tuxbox_br1-b"
ip() {
    case "$3" in tuxbox_br1-a) echo '4: eth0 inet 10.11.0.2/24 brd 10.11.0.255' ;; tuxbox_br1-b) echo '4: eth0 inet 10.11.0.4/24 brd 10.11.0.255' ;; esac
}
die() { echo "$*" >&2; return 1; }
[ "$(get_next_ip)" = 10.11.0.3 ]
printf 'network-allocation: freed address reused without colliding with occupied address\n'
