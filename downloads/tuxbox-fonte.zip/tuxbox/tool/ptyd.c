/*
 * ptyd — minimal PTY bridge daemon for the TuxBox Android app.
 *
 * Creates a Unix socket, waits for the app to connect, then spawns
 * the given command inside a new PTY and transparently bridges:
 *
 *   app socket <-> PTY master
 *
 * Protocol (binary, length-prefixed):
 *   Client -> daemon:
 *     [0x01][u32 len][bytes]   stdin data to write to PTY master
 *     [0x02][u32 len=8][r:u32 c:u32]  resize (TIOCSWINSZ)
 *   Daemon -> client:
 *     [0x01][u32 len][bytes]   output read from PTY master
 *     [0x03][u32 len=4][exit code]
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 * Copyright (C) 2026 LongQT-sea
 */
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <pty.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/prctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#define SOCK_PATH_MAX 108
#define BUF_SIZE 65536

static volatile sig_atomic_t g_child = -1;
static volatile sig_atomic_t g_child_status = 0;
static volatile sig_atomic_t g_stop = 0;
static void on_stop(int sig) { (void)sig; g_stop = 1; }
static volatile sig_atomic_t g_child_reaped = 0;

/* v3.9e: log de diagnóstico num arquivo inspecionável pelo dev (o app roda o
 * ptyd por cima de um pty e descarta o stderr), para o caso "terminal abre
 * vazio e morre": queremos saber se o filho (tuxbox) executou, com que errno
 * falhou, e com que status saiu (127 = exec falhou, 137 = SIGKILL/LMK, etc.). */
static FILE *g_log = NULL;

static void xlog(const char *fmt, ...) {
    FILE *f = g_log;
    if (!f) return;
    va_list ap;
    va_start(ap, fmt);
    vfprintf(f, fmt, ap);
    va_end(ap);
    fputc('\n', f);
    fflush(f);
}

/*
 * Bionic AArch64 requires the PT_TLS segment to be aligned to 64 bytes.
 * If no TLS symbol in the link is aligned >= 64, lld emits align=8 and the
 * loader refuses to run the binary. Force it with a real dummy TLS object.
 */
__thread char __ptyd_tls_align_pad[64] __attribute__((aligned(64)));

static void die(const char *msg) {
    fprintf(stderr, "ptyd: %s: %s\n", msg, strerror(errno));
    _exit(1);
}

static void on_sigchld(int sig) {
    (void)sig;
    /* reap our child and record its status so the final exit code is preserved */
    while (g_child > 0) {
        int st = 0;
        pid_t r = waitpid(g_child, &st, WNOHANG);
        if (r == 0) break;      /* still running */
        if (r < 0) break;       /* already reaped / error */
        g_child_status = st;
        g_child_reaped = 1;
        break;
    }
}

/* Restrict cleanup to descendants that still have the expected parent PID. */
static int owned_child(pid_t pid, pid_t parent) {
    char path[64], statbuf[4096], state;
    long ppid;
    snprintf(path, sizeof(path), "/proc/%ld/stat", (long)pid);
    FILE *file = fopen(path, "r");
    if (!file) return 0;
    char *line = fgets(statbuf, sizeof(statbuf), file);
    fclose(file);
    if (!line) return 0;
    char *end = strrchr(statbuf, ')');
    return end && sscanf(end + 1, " %c %ld", &state, &ppid) == 2 && ppid == (long)parent;
}
static void stop_descendants(pid_t parent, int sig, unsigned depth) {
    if (depth > 128) return;
    char path[96];
    snprintf(path, sizeof(path), "/proc/%ld/task/%ld/children", (long)parent, (long)parent);
    FILE *file = fopen(path, "r");
    if (!file) return;
    long child;
    while (fscanf(file, "%ld", &child) == 1) {
        if (child <= 0 || !owned_child((pid_t)child, parent)) continue;
        stop_descendants((pid_t)child, sig, depth + 1);
        if (owned_child((pid_t)child, parent)) kill((pid_t)child, sig);
    }
    fclose(file);
}

static int make_listener(const char *path) {
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd < 0) die("socket");

    struct sockaddr_un addr;
    memset(&addr, 0, sizeof(addr));
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, path, sizeof(addr.sun_path) - 1);

    unlink(path);
    if (bind(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) die("bind");
    if (listen(fd, 4) < 0) die("listen");
    return fd;
}

static int write_all(int fd, const void *buf, size_t n) {
    size_t sent = 0;
    while (sent < n) {
        ssize_t r = write(fd, (const char *)buf + sent, n - sent);
        if (r > 0) { sent += (size_t)r; continue; }
        if (r < 0 && errno == EINTR && !g_stop) continue;
        if (r < 0 && (errno == EAGAIN || errno == EWOULDBLOCK) && !g_stop) {
            struct pollfd ready = { .fd = fd, .events = POLLOUT };
            int result = poll(&ready, 1, 1000);
            if (result >= 0 || errno == EINTR) continue;
        }
        return -1;
    }
    return 0;
}

/* send a message frame to the app */
static int msg(int fd, unsigned char type, const void *payload, uint32_t len) {
    unsigned char hdr[5];
    hdr[0] = type;
    uint32_t be = htonl(len);
    memcpy(hdr + 1, &be, 4);
    if (write_all(fd, hdr, 5) < 0) return -1;
    if (len > 0 && write_all(fd, payload, len) < 0) return -1;
    return 0;
}

int main(int argc, char **argv) {
    /* v3.11 — o log fica FORA de /data/local/tuxbox: essa pasta é a base dos
     * containers e o app lista tudo que está nela, então ptyd.log aparecia
     * como "container" e quebrava a lista do app. */
    mkdir("/data/local/tuxbox-logs", 0755);
    g_log = fopen("/data/local/tuxbox-logs/ptyd.log", "a");
    int use_stdio = 0;
    const char *sock_path = NULL;
    char **cmd;

    {
        int i;
        FILE *f = g_log;
        if (f) {
            fprintf(f, "=== ptyd pid=%d argc=%d ===", getpid(), argc);
            for (i = 0; i < argc; i++) fprintf(f, " %s", argv[i]);
            fputc('\n', f);
            fflush(f);
        }
    }

    if (argc >= 3 && strcmp(argv[1], "--stdio") == 0) {
        /* stdin/stdout transport: ptyd is exec'd by the app over su,
           frames go over fd 0 (in) and fd 1 (out). */
        use_stdio = 1;
        cmd = &argv[2];
    } else if (argc >= 4) {
        sock_path = argv[1];
        cmd = &argv[2];
    } else {
        fprintf(stderr, "usage: ptyd [--stdio|<socket-path>] <cmd> [args...]\n");
        return 2;
    }

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = on_sigchld;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGCHLD, &sa, NULL);

    /* If the app closes its pipe (terminal closed), writes must fail with EPIPE
       instead of killing us outright, so we can kill the child and exit cleanly. */
    signal(SIGPIPE, SIG_IGN);
    signal(SIGTERM, on_stop);
    signal(SIGHUP, on_stop);

    int lfd = -1;
    int cfd = -1;
    if (use_stdio) {
        cfd = 1; /* use stdout fd for outgoing frames; incoming read from fd 0 */
    } else {
        lfd = make_listener(sock_path);
        cfd = accept(lfd, NULL, NULL);
        if (cfd < 0) die("accept");
        close(lfd);
    }

    /* create PTY. openpty() with a NULL winsize leaves the pty at 0 rows x
       0 cols, and full-screen TUIs (htop, opencode, vim with statuslines...)
       render NOTHING on a 0x0 tty until the app's resize frame arrives.
       Default to 80x24 so the shell always has a sane size; the first
       TIOCSWINSZ frame from the app overrides it with the real terminal size. */
    struct winsize ws0;
    ws0.ws_row = 24;
    ws0.ws_col = 80;
    ws0.ws_xpixel = 0;
    ws0.ws_ypixel = 0;
    int master, slave;
    if (openpty(&master, &slave, NULL, NULL, &ws0) < 0) die("openpty");

    /* ensure the dummy TLS object is not optimized out */
    __ptyd_tls_align_pad[0] = (char)(g_child & 1);

    // Adopt daemonized descendants so closing the PTY cannot leave them in the host.
    if (prctl(PR_SET_CHILD_SUBREAPER, 1, 0, 0, 0) < 0) xlog("subreaper unavailable: %s", strerror(errno));
    g_child = fork();
    if (g_child < 0) die("fork");

    if (g_child == 0) {
        /* child: attach pty slave to stdio and exec command */
        close(master);
        signal(SIGTERM, SIG_DFL);
        signal(SIGHUP, SIG_DFL);
        signal(SIGPIPE, SIG_DFL);
        setsid();
        if (ioctl(slave, TIOCSCTTY, 0) < 0) { /* ignore */ }
        dup2(slave, 0);
        dup2(slave, 1);
        dup2(slave, 2);
        if (slave > 2) close(slave);
        execvp(cmd[0], cmd);
        xlog("EXEC-FAIL pid=%d cmd=%s errno=%d (%s)", getpid(), cmd[0], errno, strerror(errno));
        _exit(127);
    }

    close(slave);

    int in_fd = use_stdio ? 0 : cfd;

    unsigned char inbuf[BUF_SIZE + 5];
    char outbuf[BUF_SIZE];
    size_t buffered = 0;
    int run = 1;
    int cfd_flags = fcntl(cfd, F_GETFL, 0);
    int in_flags = fcntl(in_fd, F_GETFL, 0);
    int master_flags = fcntl(master, F_GETFL, 0);
    fcntl(cfd, F_SETFL, cfd_flags | O_NONBLOCK);
    fcntl(in_fd, F_SETFL, in_flags | O_NONBLOCK);
    fcntl(master, F_SETFL, master_flags | O_NONBLOCK);

    while (run && !g_stop) {
        struct pollfd ready[2] = {
            { .fd = in_fd, .events = POLLIN },
            { .fd = master, .events = POLLIN }
        };
        int count = poll(ready, 2, g_child_reaped ? 0 : -1);
        if (count == 0 && g_child_reaped) break;
        if (count < 0) { if (errno == EINTR) continue; break; }
        if (ready[0].revents & (POLLIN | POLLHUP | POLLERR)) {
            ssize_t n = read(in_fd, inbuf + buffered, sizeof(inbuf) - buffered);
            if (n == 0) break;
            if (n < 0 && errno != EAGAIN && errno != EINTR) break;
            if (n > 0) buffered += (size_t)n;
            size_t consumed = 0;
            while (buffered - consumed >= 5) {
                unsigned char *frame = inbuf + consumed;
                uint32_t wire_length; memcpy(&wire_length, frame + 1, 4);
                uint32_t length = ntohl(wire_length);
                if (length > BUF_SIZE || (frame[0] != 0x01 && frame[0] != 0x02) ||
                        (frame[0] == 0x02 && length != 8)) { run = 0; break; }
                if (buffered - consumed < (size_t)length + 5) break;
                if (frame[0] == 0x01) {
                    if (write_all(master, frame + 5, length) < 0) { run = 0; break; }
                } else {
                    uint32_t rows, cols;
                    memcpy(&rows, frame + 5, 4); memcpy(&cols, frame + 9, 4);
                    struct winsize ws = { .ws_row = (unsigned short)ntohl(rows), .ws_col = (unsigned short)ntohl(cols) };
                    ioctl(master, TIOCSWINSZ, &ws);
                }
                consumed += (size_t)length + 5;
            }
            if (consumed) { buffered -= consumed; memmove(inbuf, inbuf + consumed, buffered); }
        }
        if (!run) break;
        if (ready[1].revents & (POLLIN | POLLHUP | POLLERR)) {
            // Bound each batch so continuous output cannot starve input or resize.
            for (int batch = 0; batch < 32; batch++) {
                ssize_t n = read(master, outbuf, sizeof(outbuf));
                if (n < 0 && (errno == EAGAIN || errno == EINTR)) break;
                if (n <= 0) { run = 0; break; }
                if (msg(cfd, 0x01, outbuf, (uint32_t)n) < 0) { run = 0; break; }
            }
        }
    }

    stop_descendants(getpid(), SIGTERM, 0);
    /* kill child if still running (client disconnected or exited) */
    int status = 0;
    if (g_child > 0) {
        int st = 0;
        pid_t r = waitpid(g_child, &st, WNOHANG);
        if (r == 0) {
            // Let the supervisor release namespaces and private resource groups.
            kill(g_child, SIGTERM);
            for (int attempt = 0; attempt < 100 && !g_child_reaped; attempt++) {
                r = waitpid(g_child, &st, WNOHANG);
                if (r != 0) break;
                usleep(20000);
            }
            if (!g_child_reaped && r == 0) {
                kill(-g_child, SIGKILL);
                kill(g_child, SIGKILL);
                while (waitpid(g_child, &st, 0) < 0 && errno == EINTR) { }
            }
        }
        if (g_child_reaped) st = g_child_status;
        if (WIFEXITED(st)) {
            status = WEXITSTATUS(st);
            xlog("CHILD pid=%d cmd=%s EXITED status=%d", g_child, cmd[0], status);
        } else if (WIFSIGNALED(st)) {
            status = 128 + WTERMSIG(st);
            xlog("CHILD pid=%d cmd=%s SIGNALED sig=%d (exit=%d)", g_child, cmd[0], WTERMSIG(st), status);
        } else {
            status = 0;
            xlog("CHILD pid=%d cmd=%s UNKNOWN status=%d", g_child, cmd[0], st);
        }
    }

    stop_descendants(getpid(), SIGKILL, 0);
    int adopted_status;
    // Signals are asynchronous: reap adopted descendants before reporting completion.
    for (int attempt = 0; attempt < 100; attempt++) {
        pid_t adopted;
        do { adopted = waitpid(-1, &adopted_status, WNOHANG); } while (adopted > 0);
        if (adopted < 0 && errno == ECHILD) break;
        stop_descendants(getpid(), SIGKILL, 0);
        usleep(10000);
    }
    /* notify exit code (big-endian, like the frame length) */
    uint32_t code = htonl((uint32_t)status);
    msg(cfd, 0x03, &code, 4);

    close(cfd);
    close(master);
    if (!use_stdio && sock_path != NULL) unlink(sock_path);
    return status;
}