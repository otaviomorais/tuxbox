package sh.tuxbox.root.util;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream;
import org.junit.Test;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.util.HashMap;
import java.util.Map;
import static org.junit.Assert.*;
public class ArchiveIntegrityTest {
    @Test public void digestMatchesKnownValueAndRejectsCorruption() throws Exception {
        File file = File.createTempFile("digest", ".txt");
        try {
            Files.write(file.toPath(), "abc".getBytes());
            String expected = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
            ArchiveIntegrity.verify(file, expected);
            assertEquals(expected, ArchiveIntegrity.manifestDigest(expected + "  rootfs.tar.xz\n", "rootfs.tar.xz"));
            Files.write(file.toPath(), "abx".getBytes());
            assertThrows(Exception.class, () -> ArchiveIntegrity.verify(file, expected));
        } finally { file.delete(); }
    }
    @Test public void rejectsTraversalAndAbsoluteMembers() {
        assertThrows(Exception.class, () -> ArchiveIntegrity.normalize("", "../../etc/passwd"));
        assertThrows(Exception.class, () -> ArchiveIntegrity.normalize("", "/etc/passwd"));
    }
    @Test public void allowsUsrMergeButRejectsHostSymlinkParentsAndCycles() throws Exception {
        Map<String,String> links = new HashMap<>(); links.put("bin", "usr/bin");
        assertEquals("usr/bin/sh", ArchiveIntegrity.resolveParents("bin/sh", links));
        links.put("etc", "/etc");
        assertThrows(Exception.class, () -> ArchiveIntegrity.resolveParents("etc/passwd", links));
        links.put("bin", "bin");
        assertThrows(Exception.class, () -> ArchiveIntegrity.resolveParents("bin/sh", links));
    }
    @Test public void rejectsArchiveThatWritesThroughAbsoluteLink() throws Exception {
        File file = File.createTempFile("archive", ".tar");
        try {
            try (TarArchiveOutputStream out = new TarArchiveOutputStream(new FileOutputStream(file))) {
                TarArchiveEntry link = new TarArchiveEntry("escape", (byte)'2'); link.setLinkName("/etc");
                out.putArchiveEntry(link); out.closeArchiveEntry();
                TarArchiveEntry entry = new TarArchiveEntry("escape/passwd"); entry.setSize(1);
                out.putArchiveEntry(entry); out.write('x'); out.closeArchiveEntry();
            }
            assertThrows(Exception.class, () -> ArchiveIntegrity.validateTar(file));
        } finally { file.delete(); }
    }    @Test public void rejectsDuplicateMemberAndHardlinkToSymlink() throws Exception {
        for (boolean duplicate : new boolean[]{true, false}) {
            File file = File.createTempFile("unsafe", ".tar");
            try {
                try (TarArchiveOutputStream out = new TarArchiveOutputStream(new FileOutputStream(file))) {
                    TarArchiveEntry link = new TarArchiveEntry("alias", (byte)'2'); link.setLinkName("/etc/passwd");
                    out.putArchiveEntry(link); out.closeArchiveEntry();
                    TarArchiveEntry entry = new TarArchiveEntry(duplicate ? "alias" : "hard", duplicate ? (byte)'0' : (byte)'1');
                    if (!duplicate) entry.setLinkName("alias");
                    out.putArchiveEntry(entry); out.closeArchiveEntry();
                }
                assertThrows(Exception.class, () -> ArchiveIntegrity.validateTar(file));
            } finally { file.delete(); }
        }
    }

}
