package sh.tuxbox.root.ui;

import android.graphics.Bitmap;
import android.view.View;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import sh.tuxbox.root.MainActivity;
import sh.tuxbox.root.R;
import sh.tuxbox.root.util.ContainerConfig;
import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.scrollTo;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.junit.Assert.*;

/** Native layout/configuration smoke test. The container shown is explicitly a UI fixture. */
@RunWith(AndroidJUnit4.class)
public class ContainerUiTest {
    private void screenshot(String name) throws Exception {
        InstrumentationRegistry.getInstrumentation().waitForIdleSync();
        Bitmap bitmap = InstrumentationRegistry.getInstrumentation().getUiAutomation().takeScreenshot();
        assertNotNull(bitmap);
        File directory = new File(InstrumentationRegistry.getInstrumentation().getTargetContext().getExternalFilesDir(null), "ui-test");
        directory.mkdirs();
        try (FileOutputStream out = new FileOutputStream(new File(directory, name + ".png"))) { bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); }
        bitmap.recycle();
    }
    @Test public void cardsConfigurationAndActivityRecreation() throws Exception {
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            scenario.onActivity(activity -> {
                activity.findViewById(R.id.btnSectionContainers).performClick();
                Fragment panel = activity.getSupportFragmentManager().getFragments().get(0);
                RootfsFragment containers = (RootfsFragment) panel.getChildFragmentManager().findFragmentByTag("dashboard_containers");
                assertNotNull(containers);
                try {
                    // No rootfs is installed or fabricated on the emulator; exercise the actual renderer.
                    Field generation = RootfsFragment.class.getDeclaredField("generation"); generation.setAccessible(true);
                    generation.setInt(containers, generation.getInt(containers) + 1);
                    Field names = RootfsFragment.class.getDeclaredField("names"); names.setAccessible(true);
                    List<String> values = (List<String>) names.get(containers); values.clear(); values.add("debian-teste");
                    Method render = RootfsFragment.class.getDeclaredMethod("render"); render.setAccessible(true); render.invoke(containers);
                    View progress = containers.requireView().findViewById(R.id.rootfsProgress); progress.setVisibility(View.GONE);
                    NestedScrollView scroll = activity.findViewById(R.id.dashboardScroll); scroll.scrollTo(0, scroll.getChildAt(0).getHeight());
                } catch (Exception e) { throw new AssertionError(e); }
            });
            onView(withText("debian-teste")).perform(scrollTo()).check(matches(isDisplayed()));
            onView(withText("Mais")).perform(scrollTo());
            screenshot("containers");
            onView(withText("Mais")).perform(click());
            onView(withText("Configurar")).perform(click());
            onView(withText("Configurar debian-teste")).check(matches(isDisplayed()));
            screenshot("configuracao");
            onView(withText("Sessão descartável (OverlayFS)")).perform(scrollTo(), click());
            onView(withText("Salvar")).perform(click());
            assertTrue(ContainerConfig.load(InstrumentationRegistry.getInstrumentation().getTargetContext(), "debian-teste").disposable);
            ContainerConfig clean = new ContainerConfig(); clean.save(InstrumentationRegistry.getInstrumentation().getTargetContext(), "debian-teste");
            scenario.recreate();
            scenario.onActivity(activity -> {
                activity.openTerminalTab("debian-teste");
                assertNotNull(activity.findViewById(R.id.terminalView));
                activity.showPanelPage();
            });
        }
    }
}
