// SPDX-License-Identifier: GPL-3.0-only
package sh.tuxbox.root.util;
import java.util.List;
public final class ShellWords {
    private ShellWords() {}
    public static String quote(String value) { return "'" + value.replace("'", "'\"'\"'") + "'"; }
    public static String join(List<String> argv) {
        StringBuilder result = new StringBuilder();
        for (String value : argv) { if (result.length() > 0) result.append(' '); result.append(quote(value)); }
        return result.toString();
    }
    public static String name(String value) {
        if (value == null || !value.matches("[A-Za-z0-9][A-Za-z0-9._-]{0,63}"))
            throw new IllegalArgumentException("Nome: até 64 letras, números, ponto, hífen ou sublinhado.");
        return value;
    }
}
