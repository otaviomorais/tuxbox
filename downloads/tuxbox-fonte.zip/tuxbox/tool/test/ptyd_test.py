#!/usr/bin/env python3
"""Exercise the actual framed PTY bridge on Linux, without Android or a mock transport."""
import os
import select
import signal
import struct
import subprocess
import sys
import tempfile
import time
import unittest
BINARY = sys.argv.pop(1)

def frame(kind, payload):
    return bytes([kind]) + struct.pack('!I', len(payload)) + payload

def collect(process, timeout=10):
    deadline = time.monotonic() + timeout
    wire = bytearray()
    while time.monotonic() < deadline:
        ready, _, _ = select.select([process.stdout], [], [], max(0, deadline - time.monotonic()))
        if not ready:
            break
        chunk = os.read(process.stdout.fileno(), 65536)
        if not chunk:
            break
        wire += chunk
    else:
        process.kill()
        raise AssertionError('PTY bridge hung')
    process.wait(timeout=3)
    output = bytearray()
    code = None
    while wire:
        if len(wire) < 5:
            raise AssertionError('partial output header')
        kind, length = wire[0], struct.unpack('!I', wire[1:5])[0]
        if len(wire) < length + 5:
            raise AssertionError('partial output payload')
        payload = wire[5:5 + length]
        if kind == 1:
            output += payload
        elif kind == 3:
            code = struct.unpack('!I', payload)[0]
        else:
            raise AssertionError('unknown output type')
        del wire[:5 + length]
    return bytes(output), code

class BridgeTests(unittest.TestCase):
    def start(self, command):
        process = subprocess.Popen([BINARY, '--stdio', '/bin/sh', '-c', command], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        def cleanup():
            if process.poll() is None:
                process.kill(); process.wait(timeout=3)
            for pipe in (process.stdin, process.stdout, process.stderr):
                if pipe is not None:
                    pipe.close()
        self.addCleanup(cleanup)
        return process

    def test_split_header_and_payload_preserve_session_and_exit(self):
        process = self.start('stty -echo; read line; printf "RESULT=%s\\n" "$line"; exit 23')
        data = frame(1, b'fragmented\n')
        for chunk in (data[:2], data[2:4], data[4:8], data[8:]):
            process.stdin.write(chunk); process.stdin.flush(); time.sleep(0.02)
        output, status = collect(process)
        self.assertIn(b'RESULT=fragmented', output)
        self.assertEqual(status, 23)
        self.assertEqual(process.returncode, 23)

    def test_resize_and_multiple_frames(self):
        process = self.start('stty -echo; read line; stty size')
        data = frame(2, struct.pack('!II', 42, 100)) + frame(1, b'go\n')
        process.stdin.write(data); process.stdin.flush()
        output, status = collect(process)
        self.assertIn(b'42 100', output)
        self.assertEqual(status, 0)

    def test_slow_reader_receives_all_output(self):
        process = self.start('head -c 2000000 /dev/zero; exit 17')
        time.sleep(0.1)
        output, status = collect(process, 15)
        self.assertEqual(len(output), 2000000)
        self.assertEqual(status, 17)

    def test_disconnect_terminates_child(self):
        process = self.start('sleep 60')
        process.stdin.close()
        _, status = collect(process, 5)
        self.assertIsNotNone(status)
        self.assertNotEqual(status, 0)

    def test_background_descendant_does_not_keep_terminal_alive(self):
        with tempfile.TemporaryDirectory() as temp:
            pidfile = os.path.join(temp, 'pid')
            process = self.start(f'sleep 60 & echo $! > "{pidfile}"; echo background-started; exit 0')
            output, status = collect(process, 5)
            self.assertIn(b'background-started', output)
            self.assertEqual(status, 0)
            with open(pidfile) as source:
                pid = int(source.read().strip())
            try:
                with open(f'/proc/{pid}/stat') as source:
                    state = source.read().split(') ', 1)[1].split()[0]
                self.assertEqual(state, 'Z', 'background child remained alive')
            except FileNotFoundError:
                pass

    def test_malformed_frame_is_rejected(self):
        process = self.start('sleep 60')
        process.stdin.write(b'\x01' + struct.pack('!I', 65537)); process.stdin.flush()
        _, status = collect(process, 5)
        self.assertNotEqual(status, 0)

if __name__ == '__main__':
    unittest.main(verbosity=2)
