// SPDX-License-Identifier: GPL-3.0-only
package sh.tuxbox.root;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import com.termux.terminal.TerminalSession;
import com.termux.terminal.TerminalSessionClient;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import sh.tuxbox.root.util.AssetInstaller;
import sh.tuxbox.root.util.ContainerConfig;
import sh.tuxbox.root.util.ShellWords;
import sh.tuxbox.root.util.TuxPaths;

/** Application-owned processes and terminal buffers. All state changes run on the main thread. */
public final class SessionManager {
    public static final class Session {
        public final String id, label;
        public final boolean net;
        public final TerminalSession session;
        public final Process process;
        public final long startedAt = System.currentTimeMillis();
        public Integer exitCode;
        private final Client client;
        private volatile String stderr = "";
        Session(String id, String label, boolean net, Process process, TerminalSession session, Client client) {
            this.id = id; this.label = label; this.net = net;
            this.process = process; this.session = session; this.client = client;
        }
        public boolean running() { return exitCode == null && process.isAlive(); }
        public String diagnostics() { return stderr; }
    }
    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newCachedThreadPool();
    private final List<Session> sessions = new ArrayList<>();
    private final List<Runnable> listeners = new ArrayList<>();
    private int active = -1, launching, stopEpoch;
    private final java.util.Map<String, Integer> launchRevisions = new java.util.HashMap<>();
    private final java.util.Map<String, String> operations = new java.util.HashMap<>();
    public String operationLabel(String name) { return operations.get(name); }
    public int operationCount() { return operations.size(); }
    public void beginOperation(String name, String label) {
        if (operations.containsKey(name)) throw new IllegalStateException("Operação já em andamento neste container");
        operations.put(name, label); changed();
    }
    public void finishOperation(String name) { operations.remove(name); changed(); }
    private final java.util.Map<String, List<String>> recovered = new java.util.HashMap<>();
    public int recoveredCount(String name) { return recovered.containsKey(name) ? recovered.get(name).size() : 0; }
    public void reconcileRootState(String output) {
        recovered.clear();
        for (String line : output.split("\\r?\\n")) {
            String[] fields = line.split("\\|", -1);
            if (fields.length != 4 || !fields[0].matches("[a-f0-9-]+") || !fields[1].startsWith(TuxPaths.ROOTFS_BASE + "/")) continue;
            boolean local = false; for (Session s : sessions) if (s.id.equals(fields[0])) local = true;
            if (local) continue;
            String name = fields[1].substring(TuxPaths.ROOTFS_BASE.length() + 1);
            try { ShellWords.name(name); } catch (IllegalArgumentException e) { continue; }
            recovered.computeIfAbsent(name, ignored -> new ArrayList<>()).add(fields[0]);
        }
        for (Runnable listener : new ArrayList<>(listeners)) listener.run();
    }

    SessionManager(Context context) { this.context = context.getApplicationContext(); }
    public static SessionManager get(Context context) { return ((App) context.getApplicationContext()).sessions(); }
    public List<Session> sessions() { return Collections.unmodifiableList(sessions); }
    public int activeIndex() { return active; }
    public void activate(int index) { if (index >= 0 && index < sessions.size()) { active = index; changed(); } }
    public int runningCount() {
        int count = localRunningCount(); for (List<String> ids : recovered.values()) count += ids.size(); return count;
    }
    private int localRunningCount() { int count = 0; for (Session s : sessions) if (s.running()) count++; return count; }
    public boolean hasWork() { return launching > 0 || localRunningCount() > 0 || !operations.isEmpty(); }
    public boolean isRunning(String name) { for (Session s : sessions) if (s.label.equals(name) && s.running()) return true; return recoveredCount(name) > 0; }
    public void observe(Runnable listener) { if (!listeners.contains(listener)) listeners.add(listener); }
    public void unobserve(Runnable listener) { listeners.remove(listener); }
    public void attach(Session s, TerminalSessionClient client) { s.client.delegate = client; }
    public void detach(TerminalSessionClient client) { for (Session s : sessions) if (s.client.delegate == client) s.client.delegate = null; }

    public void launch(String name, boolean net, boolean gui, Consumer<String> done) {
        launch(name, net, gui, null, done);
    }
    public void launchTemplate(String name, String template, Consumer<String> done) {
        if (!java.util.Arrays.asList("development", "desktop", "services").contains(template)) {
            done.accept("Template inválido"); return;
        }
        launch(name, false, false, template, done);
    }
    private void launch(String name, boolean net, boolean gui, String template, Consumer<String> done) {
        if (operations.containsKey(name)) { done.accept("Rootfs em manutenção; aguarde a operação atual."); return; }
        final int epoch = stopEpoch, revision = launchRevisions.getOrDefault(name, 0);
        final ContainerConfig config;
        try { config = ContainerConfig.load(context, name); config.validate(); }
        catch (Exception e) { done.accept(e.getMessage() == null ? e.toString() : e.getMessage()); return; }
        launching++;
        TerminalService.start(context, name);
        changed();
        worker.execute(() -> {
            Process process = null;
            try {
                AssetInstaller.install(context);
                String bin = AssetInstaller.binDir(context).getAbsolutePath();
                String id = UUID.randomUUID().toString();
                List<String> argv = new ArrayList<>();
                argv.add(AssetInstaller.ptydPath(context).getAbsolutePath()); argv.add("--stdio");
                argv.add(bin + "/tuxbox-managed"); argv.add(id);
                argv.add("--profile"); argv.add(config.profile);
                if (config.disposable) argv.add("--disposable");
                if (net) argv.add("--net");
                if (gui) argv.add("--gui");
                if (net && !config.ports.isEmpty()) { argv.add("--port-range"); argv.add(config.ports); }
                if (!config.sharedDirectory.isEmpty()) {
                    argv.add("--share-dir"); argv.add(config.sharedDirectory);
                    argv.add(config.readOnly ? "--share-readonly" : "--share-writable");
                }
                argv.add(TuxPaths.ROOTFS_BASE + "/" + name);
                if (template != null) {
                    argv.add("/bin/sh"); argv.add("-c");
                    argv.add("/usr/local/bin/tuxbox-template " + ShellWords.quote(template) + "; rc=$?; echo Template_exit=$rc; exec /bin/sh -il");
                }
                String cmd = "exec " + ShellWords.join(argv);
                ProcessBuilder builder = new ProcessBuilder("su", "-c", cmd);
                builder.environment().put("TERM", "xterm-256color");
                process = builder.start();
                final Process proc = process;
                main.post(() -> {
                    try {
                        if (epoch != stopEpoch || revision != launchRevisions.getOrDefault(name, 0)) {
                            proc.destroy(); launching--; changed(); done.accept("Inicialização cancelada"); return;
                        }
                        Client client = new Client(this);
                        TerminalSession terminal = new TerminalSession(proc.getInputStream(), proc.getOutputStream(), 2000, client);
                        terminal.updateSize(80, 24, 0, 0);
                        Session record = new Session(id, name, net, proc, terminal, client);
                        sessions.add(record); active = sessions.size() - 1;
                        worker.execute(() -> drainErrors(record));
                        worker.execute(() -> {
                            try { int code = proc.waitFor(); main.post(() -> exited(record, code)); }
                            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                        });
                        launching--; changed(); done.accept(null);
                    } catch (Exception e) { proc.destroy(); launching--; changed(); done.accept(e.getMessage() == null ? e.toString() : e.getMessage()); }
                });
            } catch (Exception e) {
                if (process != null) process.destroy();
                main.post(() -> { launching--; changed(); done.accept(e.getMessage() == null ? e.toString() : e.getMessage()); });
            }
        });
    }
    private void drainErrors(Session s) {
        try (BufferedReader input = new BufferedReader(new InputStreamReader(s.process.getErrorStream()))) {
            String line;
            while ((line = input.readLine()) != null) {
                String next = s.stderr + line + "\n";
                s.stderr = next.substring(Math.max(0, next.length() - 8192));
            }
        } catch (Exception e) { Log.d("TuxBox", "stderr closed", e); }
    }
    private void exited(Session s, int code) {
        if (!sessions.contains(s) || s.exitCode != null) return;
        s.exitCode = code; s.session.notifyProcessExited(code); changed();
    }
    public void stop(String name) {
        launchRevisions.put(name, launchRevisions.getOrDefault(name, 0) + 1);
        for (Session s : new ArrayList<>(sessions)) if (s.label.equals(name)) close(sessions.indexOf(s));
        List<String> ids = recovered.remove(name);
        if (ids != null) for (String id : ids) worker.execute(() -> RootShell.run("sh "
                + ShellWords.quote(new File(AssetInstaller.binDir(context), "tuxbox-control").getAbsolutePath()) + " stop " + ShellWords.quote(id)));
        changed();
    }
    public void stopAll() {
        stopEpoch++;
        while (!sessions.isEmpty()) close(sessions.size() - 1);
        for (String name : new ArrayList<>(recovered.keySet())) stop(name);
    }
    public void close(int index) {
        if (index < 0 || index >= sessions.size()) return;
        Session s = sessions.remove(index); s.client.delegate = null;
        if (index < active) active--;
        active = sessions.isEmpty() ? -1 : Math.min(Math.max(0, active), sessions.size() - 1);
        worker.execute(() -> {
            // Ask the root supervisor to stop descendants before closing the PTY.
            s.session.finishIfRunning(); s.process.destroy();
            try {
                RootShell.run("sh " + ShellWords.quote(new File(AssetInstaller.binDir(context), "tuxbox-control").getAbsolutePath())
                        + " stop " + ShellWords.quote(s.id));
            } finally { s.session.finishIfRunning(); s.process.destroy(); }
        });
        changed();
    }
    private void changed() {
        for (Runnable listener : new ArrayList<>(listeners)) listener.run();
        if (hasWork()) TerminalService.start(context, !operations.isEmpty() ? operations.values().iterator().next()
                : sessions.isEmpty() ? "Iniciando…" : sessions.get(Math.max(0, active)).label);
        else TerminalService.stop(context);
    }
    private static final class Client implements TerminalSessionClient {
        TerminalSessionClient delegate;
        Client(SessionManager owner) { }
        public void onTextChanged(TerminalSession s) { if (delegate != null) delegate.onTextChanged(s); }
        public void onTitleChanged(TerminalSession s) { if (delegate != null) delegate.onTitleChanged(s); }
        public void onSessionFinished(TerminalSession s) {
            // The process waiter records the actual exit code, independently of the view.
            if (delegate != null) delegate.onSessionFinished(s);
        }
        public void onCopyTextToClipboard(TerminalSession s, String text) { if (delegate != null) delegate.onCopyTextToClipboard(s, text); }
        public void onPasteTextFromClipboard(TerminalSession s) { if (delegate != null) delegate.onPasteTextFromClipboard(s); }
        public void onBell(TerminalSession s) { if (delegate != null) delegate.onBell(s); }
        public void onColorsChanged(TerminalSession s) { if (delegate != null) delegate.onColorsChanged(s); }
        public void onTerminalCursorStateChange(boolean state) { if (delegate != null) delegate.onTerminalCursorStateChange(state); }
        public Integer getTerminalCursorStyle() { return delegate == null ? null : delegate.getTerminalCursorStyle(); }
        public void logError(String tag, String message) { Log.e(tag, message); }
        public void logWarn(String tag, String message) { Log.w(tag, message); }
        public void logInfo(String tag, String message) { Log.i(tag, message); }
        public void logDebug(String tag, String message) { Log.d(tag, message); }
        public void logVerbose(String tag, String message) { Log.v(tag, message); }
        public void logStackTraceWithMessage(String tag, String message, Exception e) { Log.e(tag, message, e); }
        public void logStackTrace(String tag, Exception e) { Log.e(tag, "terminal", e); }
    }
}
