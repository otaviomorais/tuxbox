#!/bin/sh
set -eu
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SOURCE="$HERE/../../app/src/main/assets/bin"
TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
export TB_BASE="$TMP/rootfs" TB_STATE_BASE="$TMP/state" TB_ARCHIVES="$TMP/archives" TB_LOCKS="$TMP/locks"
mkdir -p "$TB_BASE/debian/etc" "$TB_BASE/debian/usr/bin" "$TB_BASE/debian/bin" "$TB_STATE_BASE"
printf secret > "$TB_BASE/debian/etc/private"; chmod 600 "$TB_BASE/debian/etc/private"
ln -s /bin/sh "$TB_BASE/debian/bin/sh"
CONTROL="$SOURCE/tuxbox-control"
sh "$CONTROL" clone debian copy
[ "$(cat "$TB_BASE/copy/etc/private")" = secret ]
[ "$(stat -c %a "$TB_BASE/copy/etc/private")" = 600 ]
if sh "$CONTROL" clone debian copy >/dev/null 2>&1; then echo 'overwrote existing clone'; exit 1; fi
if sh "$CONTROL" delete ../rootfs >/dev/null 2>&1; then echo 'accepted traversal'; exit 1; fi
sh "$CONTROL" backup debian
FILE=$(find "$TB_ARCHIVES" -name '*.tar' | head -n1)
[ "$(sha256sum "$FILE" | awk '{print $1}')" = "$(cat "$FILE.sha256")" ]
sh "$CONTROL" install restored "$FILE"
[ "$(stat -c %a "$TB_BASE/restored/etc/private")" = 600 ]
if sh "$CONTROL" install restored "$FILE" >/dev/null 2>&1; then echo 'overwrote installed rootfs'; exit 1; fi
sh "$CONTROL" delete restored
[ ! -e "$TB_BASE/restored" ]
# An old PID file must not terminate a new process that reused that PID.
sleep 60 & CHILD=$!
mkdir "$TB_STATE_BASE/aa-bb"
printf '%s\n' "$CHILD" > "$TB_STATE_BASE/aa-bb/pid"
printf 'invalid-token\n' > "$TB_STATE_BASE/aa-bb/token"
sh "$CONTROL" stop aa-bb
kill -0 "$CHILD"
sh "$CONTROL" status
[ ! -d "$TB_STATE_BASE/aa-bb" ]
kill "$CHILD"; wait "$CHILD" 2>/dev/null || true
# An interrupted file operation must not leave the container permanently locked.
mkdir -p "$TB_LOCKS/debian"
printf 99999999 > "$TB_LOCKS/debian/pid"; printf stale > "$TB_LOCKS/debian/token"
sh "$CONTROL" clone debian recovered
[ -f "$TB_BASE/recovered/etc/private" ]
# A live supervisor blocks mutating operations.
mkdir "$TB_STATE_BASE/cc-dd"
printf '%s\n' "$$" > "$TB_STATE_BASE/cc-dd/pid"
sed 's/.*) //' /proc/$$/stat | awk '{print $20}' > "$TB_STATE_BASE/cc-dd/token"
printf '%s\n' "$TB_BASE/debian" > "$TB_STATE_BASE/cc-dd/rootfs"
printf unlimited > "$TB_STATE_BASE/cc-dd/profile"
if sh "$CONTROL" delete debian >/dev/null 2>&1; then echo 'deleted live rootfs'; exit 1; fi
if sh "$CONTROL" backup debian >/dev/null 2>&1; then echo 'backed up live rootfs'; exit 1; fi
[ -f "$TB_BASE/debian/etc/private" ]
# Exercise the supervisor with a harmless local command instead of namespaces.
mkdir "$TMP/bin" "$TMP/bin/modules"
cp "$SOURCE/tuxbox-managed" "$TMP/bin/"
cp "$SOURCE/modules/runtime.sh" "$TMP/bin/modules/"
printf '#!/bin/sh\nprintf child-ok\\n\nexit 7\n' > "$TMP/bin/tuxbox"
chmod +x "$TMP/bin/tuxbox"
set +e
sh "$TMP/bin/tuxbox-managed" ee-ff --profile unlimited "$TB_BASE/debian" > "$TMP/launch.log" 2>&1
RESULT=$?
set -e
[ "$RESULT" = 7 ]
[ ! -d "$TB_STATE_BASE/ee-ff" ]
printf 'container-control: all checks passed\n'
# Disposable execution writes to an overlay, then leaves the original unchanged.
if unshare -m true 2>/dev/null; then
    cat > "$TMP/bin/tuxbox" <<'STUB'
#!/bin/sh
[ -n "$TB_ROOTFS_OVERRIDE" ]
printf temporary > "$TB_ROOTFS_OVERRIDE/etc/disposable"
[ ! -f "$1/etc/disposable" ]
STUB
    chmod +x "$TMP/bin/tuxbox"
    # The previous live-state fixture belongs to this test process; remove it.
    rm -rf "$TB_STATE_BASE/cc-dd"
    sh "$TMP/bin/tuxbox-managed" ab-cd --profile unlimited --disposable "$TB_BASE/debian"
    [ ! -e "$TB_BASE/debian/etc/disposable" ]
    [ ! -d "$TB_STATE_BASE/ab-cd" ]
    echo 'disposable overlay: passed'
else echo 'disposable overlay: unavailable in this executor (skipped)'; fi
