# Segurança

## Antes de usar

O TuxBox é software experimental com acesso **root**. Ele cria namespaces,
montagens, device nodes, regras de rede e, no modo gráfico, pode interacts
com SELinux e com bibliotecas da distro. Faça backup, use um aparelho que
você possa recuperar e leia esta página antes de instalar.

O repositório e as releases **não incluem jogos, ROMs, saves, keys de licença,
imagens rootfs ou outros arquivos de conteúdo**. As imagens Linux são
baixadas em tempo de execução pelo usuário e ficam no armazenamento local.

## Compromissos conhecidos

- **Mesa GPU:** downloads automáticos exigem SHA-256 do asset na API GitHub.
  O hash é conferido antes da extração. Isso verifica integridade em relação ao
  publicador via HTTPS, não uma assinatura independente.
- **Arch Linux:** `DisableSandbox` continua necessário em kernels sem Landlock;
  os helpers usam assinaturas obrigatórias e `TrustedOnly`. A confiança da keyring
  oficial é inicializada sem relaxar assinaturas de repositório para `TrustAll`.
- **Downloader legado:** `getroot` verifica TLS e tenta bloquear o login por senha
  de root, sem definir uma senha universal. O fluxo principal não usa esse helper.
- **SELinux:** a GUI não altera mais o modo global com `setenforce 0`. Bloqueios
  precisam ser diagnosticados na ROM, preservando a política do host.
- **Bibliotecas da distro:** a instalação Mesa em Debian/Ubuntu pode usar
  `dpkg-divert` para impedir que o gerenciador de pacotes sobrescreva o
  Turnip customizado.
- **Rede:** `--net` cria bridge, namespaces de rede, NAT e regras de firewall
  no aparelho. A rede permanece desligada por padrão.
- **Downloads rootfs:** a aba principal usa HTTPS e o índice público do
  linuxcontainers.org, mas as imagens e seus mantenedores têm seus próprios
  termos e riscos. Novos downloads são conferidos contra SHA256SUMS via HTTPS; importações locais e caches legados sem manifesto exigem confiança na imagem. A extração usa staging e valida caminhos antes de executar tar como root.

Essas escolhas são necessárias para compatibilidade com containers Android,
mas ampliam a superfície de ataque. Não existe garantia de isolamento contra
um kernel comprometido ou um exploit no sistema host.

## Relato privado

Não abra uma issue pública para uma vulnerabilidade explorável. Use
[Security Advisories do repositório](https://github.com/otaviomorais/tuxbox/security/advisories/new)
e inclua:

- versão do TuxBox e do Android;
- modelo/ROM e kernel;
- passos de reprodução;
- impacto e PoC mínimo;
- logs já sanitizados.

O projeto não oferece garantia formal de resposta ou suporte de segurança.
