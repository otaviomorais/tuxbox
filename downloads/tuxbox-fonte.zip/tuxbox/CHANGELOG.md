# Changelog

Todas as mudanças relevantes do TuxBox serão registradas aqui. O formato é
baseado em [Keep a Changelog](https://keepachangelog.com/pt-BR/1.1.0/) e o
projeto segue [versionamento semântico](https://semver.org/lang/pt-BR/).

## [1.1.0-dev] — 2026-10-14

- Painel com cards de estado, sessões, iniciar/parar e menu de gestão.
- Sessões controladas pela Application, com buffers independentes da view,
  códigos de saída reais e desligamento de processos descendentes.
- PTY tolerante a pacotes fragmentados e leitores lentos; espera por eventos,
  sem o polling fixo de 10 ms; helpers reconstruídos para as três ABIs.
- Perfis CPU/RAM por sessão, camada OverlayFS descartável, pastas compartilhadas
  somente leitura por padrão e configuração de portas.
- Backup/clonagem/instalação transacional, preservação de modos/ownership,
  locks recuperáveis e proteção contra manutenção de rootfs ativo.
- Templates de desenvolvimento, XFCE e serviços, com saída no terminal.
- Consulta de capacidades e alocação/limpeza de rede por sessão.
- SHA-256 e validação de tar antes da instalação; TrustedOnly em pacman,
  TLS verificado no helper legado e ausência de senha universal de root.
- GUI preserva o SELinux global; os programas guest deixam de ser imunes ao OOM.
- APK Dev com ID separado; [detalhes e limites de validação](docs/management.md).

## [1.0.0-v3.47] — 2026-09-25

### Primeira release pública

- app Android para rootfs Linux com namespaces, bind mounts e
  `pivot_root/chroot`, sem `systemd-nspawn`;
- instalação e importação de rootfs do linuxcontainers.org;
- gerenciador de containers, reparo de permissões e remoção segura;
- terminal multi-aba com ponte PTY nativa e foreground service;
- opções de namespace de rede e Termux:X11;
- servidor X11 compartilhado com watchdog e recuperação automática;
- instalação de XKB, clientes X11 e gerenciador de janelas;
- diagnóstico de GPU e instalação Mesa/Turnip;
- diagnóstico real das capacidades do kernel/root;
- logs de boot, X11, watchdog, GPU e PTY;
- código de terminal adaptado do Termux sob GPL-3.0-only;
- documentação, avisos de segurança e build reproduzível com Gradle 8.9.

### Segurança

- O modo GUI pode tentar `setenforce 0` em ROMs compatíveis.
- O helper Arch usa `TrustAll` no `pacman.conf` para contornar keyrings
  antigas; isso não restringe a confiança exclusivamente à keyring oficial.
- O instalador Mesa pode extrair assets de terceiro como root e não fixa um
  hash/assinatura independente.
- Consulte [SECURITY.md](SECURITY.md) antes de usar.

[1.0.0-v3.47]: https://github.com/otaviomorais/tuxbox/releases/tag/v1.0.0-v3.47
